import "./Header.css";

const Header = () => {
    return (
      <header>
          <h1>Age Calculator</h1>
      </header>
    )
  }
  
  export default Header;