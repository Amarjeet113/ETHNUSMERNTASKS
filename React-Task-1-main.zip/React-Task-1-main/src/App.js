import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Word from "./Components/Word";
function App() {
  return (
    <div>
      <Word />
    </div>
  );
}

export default App;
